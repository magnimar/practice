from os import RTLD_NODELETE
import random
import hashlib

'''crypto environment where you can mine MagniCoin and transfer to other accounts'''

class MagniCoin:
    def __init__(self, account_in_action = None):
        self.account_in_action = account_in_action
        self.account_and_password = {}
        self.account_and_coincount = {}
        self.last_mine = 0
        self.coins_in_account = 0

    def play_game(self):
        self.accounts_to_list()
        self.coins_to_list()
        self.login()
        self.set_coin_variable()
        self.display_coins()
        self.transfer_coins()
        self.mine()

    def transfer_coins(self):
        '''function where you can transfer coins to another existing account, function changes the ledger of the other account'''
        trans = input("Do you want to transfer coins to another account? (y|n) ")
        if trans == "n":
            return
        receiver_account = input("Who do you want to transfer to? ")
        if receiver_account not in self.account_and_password:
            print("Account does not exist \n")
            return self.transfer_coins()
        transfer_amount = input("How much do you want to transfer? ")
        if not transfer_amount.isnumeric():
            print("Not a number.\n")
            return self.transfer_coins()
        if int(transfer_amount) > self.account_and_coincount[self.account_in_action]:
            print("You don't have enough coins for that.\n")
            return self.transfer_coins()
        self.account_and_coincount[self.account_in_action] -= int(transfer_amount)
        self.change_ledger(-int(transfer_amount), self.account_in_action)
        self.account_and_coincount[receiver_account] += int(transfer_amount)
        self.change_ledger(transfer_amount, receiver_account)
        print("Amount has been transferred.\n")

    def set_coin_variable(self):
        '''changes the class coin variable to have the coin value of the current account'''
        if self.account_in_action in self.account_and_coincount:
            self.coins_in_account = self.account_and_coincount[self.account_in_action]

    def display_coins(self):
        '''prints how many coins the account has'''
        print(f"Your account has {self.coins_in_account} coins.\n")

    def coins_to_list(self):
        '''converts database to accessable list in the class'''
        coins = open("coin_per_account.txt", "r")
        for line in coins:
            account = line.split()[0]
            coin = line.split()[1]
            if account in self.account_and_coincount:
                self.account_and_coincount[account] += int(coin)
            else:
                self.account_and_coincount[account] = int(coin)

    def mine(self):
        '''function to mine the coin, once the coin has been mined it is added to your account'''
        counter = 0
        while True:
            rand_num1 = random.randint(0, 1000)
            rand_num2 = random.randint(0, 2000)
            answer = rand_num1 + rand_num2
            mining_answer = input(f"What is {rand_num1} + {rand_num2}? ")
            if not mining_answer.isnumeric():
                print("Not a number.\n")
                return self.mine()
            if int(mining_answer) == answer:
                counter += 1
                print("Correct! You have successfully mined 1 MagniCoin.\n")
                cont = input("Do you want to continue mining the innovative MagniCoin? (y|n) \n")
                if cont == "n":
                    self.last_mine = counter
                    print("You have added ", self.last_mine, " MagniCoin to your account.\n")
                    self.change_ledger(self.last_mine, self.account_in_action)
                    return
            else:
                print("Wrong, no MagniCoin for you.\n")
                cont = input("Do you want to try again? (y|n) ")
                if cont == "n":
                    self.last_mine = counter
                    print(f"You have mined {self.last_mine}\n")
                    self.change_ledger(self.last_mine, self.account_in_action)
                    return

    def change_ledger(self, amount, account):
        '''changes the ledger of your account'''
        coins = open("coin_per_account.txt", "a")
        coins.write(f"{account} {amount} \n")
        coins.close()

    def accounts_to_list(self):
        '''transfers the accounts and hashes of the passwords to an accsessible dict in the class'''
        file = open("accounts_and_passwords.txt", "r")
        for line in file:
            self.account_and_password[line.split()[0]] = line.split()[1]

    def login(self):
        '''account system uses a triple SHA256 hash with salting, salt consists of the username so that every hahs is unique'''
        account_name = input("What is your username?: ")
        if account_name in self.account_and_password:
            password = input("What is your password?: ")
            hash = self.make_hash(password, account_name)
            if self.account_and_password[account_name] == hash:
                print("Correct password.\n")
                self.account_in_action = account_name
                return
            else:
                print("Wrong password.\n")
                return self.login()
        else:
            password = input("What password do you want?: \n")
            hash = self.make_hash(password, account_name)
            self.account_and_password[account_name] = hash
            self.add_to_file(account_name, hash)
            self.account_in_action = account_name

    def add_to_file(self, account, hash):
        '''adds account and hash of account to database'''
        file = open("accounts_and_passwords.txt", "a")
        file.write(f"{account} {hash} \n")
        file.close()

    def make_hash(self, password, account):
        '''creates a hash according to username and password, triple SHA256 with salting'''
        account_hash = hashlib.sha256(account.encode()).hexdigest()
        hash = hashlib.sha256(password.encode()).hexdigest()
        hash = hashlib.sha256(hash.encode()).hexdigest()
        hash = hashlib.sha256(hash.encode()).hexdigest()
        account_password_string = account_hash + hash
        final_hash = hashlib.sha256(account_password_string.encode()).hexdigest()
        return final_hash

m = MagniCoin()
m.play_game()