from os import read, write
import random
import hashlib

class Hangman:

    '''class variables that contain strings that are frequently used or very long'''
    greeting = "\nWelcome to Top Gun Hangman! If you already have an account you can use the same username but if you don't have an account you can input the username that you would like to use. (Maverick or Goose is highly recommended)" 
    jetwash = "\nYou have been jetwashed! Try again."
    again = "\nDo you want to play the highly sucessful Top Gun Hangman again? (y|n)"
    point_system = "\nThe point system for each game follows these rules: a game starts with 50 points. For a one letter guess -15 points are deducted for a wrong guess and 15 points rewarded for a correct guess. For a multiple letter guess: -10 points for each letter that is wrong and +10 for each letter that is correct. If a player loses the game he gets 0 points. How many guesses do you want? Maverick never uses more than 6: "
    game_won = "\nYou have been picked for Top Gun!"
    already_guessed = "\nYou have already guessed this."
    correct_guess = "\nGuess is correct, hombre!"
    wrong_guess = "\nGuess is wrong, Goose!"
    add_to_wordbank = "\nDo you want to add a word to the Top Gun wordbank? Top Gun related words such as need, speed, jetwash, birdie, buzz, inverted, goose, talk, forever, fly, dangerous, jet, ego and wingman are highly recommended (y|n) "
    
    def __init__(self, account_in_action=None, word=None, revealed_word=None):
        '''the class keeps track of what account is currently being played on, what word is the user trying to guess, along with that same word with letters that have been guessed displayed and the rest as -, false guesses in a list, the list of all accounts that have played, list of all words that are in the data bank, how many words are in the data bank, how many guesses the user has left, his score for the current game and whether the game has been won or lost'''
        self.account_in_action = account_in_action
        self.word = word
        self.revealed_word = revealed_word
        self.false_guesses = []
        self.total_account_list = {}
        self.total_word_list = []
        self.account_scores = {}
        self.total_word_counter = 0
        self.guesses = 0
        self.score = 0
        self.win_loss = True


    def start_game(self):
        '''this function starts the game and converts the data bank for words into a list that can be accessed so that the word bank only needs to be traversed once, converts the accounts that have played a game into a list for the same reason along with the scores for each account, because this only needs to be done once at the start of the game the function calls on a play game function that can be run multiple times'''
        self.words_to_list()
        self.accounts_to_list()
        self.scores_to_list()
        self.play_game()

    def play_game(self):
        '''functon that logs in an account, this is only called once'''
        self.account()
        self.final_play_game()

    def final_play_game(self):
        '''function that can be run multiple times and runs through a single game of hangman along with all necessary processes, can be run again and again'''
        self.display_score()
        self.new_word()
        self.select_word()
        self.guess_game()
        self.keep_score()
        self.play_again()

    def play_again(self):
        '''asks the user if the wants to play another game and then initializes another game, if not the program ends'''
        play_again = str(input(Hangman.again))
        if play_again == "y":
            self.guesses = 0
            self.score = 0
            return self.final_play_game()

    def display_score(self):
        '''finds the past games of the current account and finds the highscore of the account'''
        if self.account_in_action in self.account_scores:
            past_scores = []
            for i in range(0, len(self.account_scores[self.account_in_action]), 2):
                past_scores.append(int(self.account_scores[self.account_in_action][i]))
            high_score = max(past_scores)
            past_scores = ", ".join(str(val) for val in self.account_scores[self.account_in_action])
            print("\nThe last dogfights for {} came in and are {} and the high score is {}.".format(self.account_in_action, past_scores, high_score))
        else:
            print("\nThis hombre does not seem to have any past dogfights! Time to fix that.")
            return

    def keep_score(self):
        '''adds the score of the game that was played and adds it to the database'''
        print("\nThe highly classified Top Gun score for this dogfight was: {}\n".format(self.score))
        if self.win_loss:
            win_loss = "win"
        else:
            win_loss = "loss"
        input_string = str(self.account_in_action) + " " + str(self.score) + " " + str(win_loss) + "\n"
        scores = open("account_scores.txt", "a")
        scores.write(input_string)
        scores.close()
        if self.account_in_action in self.account_scores:
            self.add_score_to_account(win_loss)
        else:
            self.account_scores[self.account_in_action] = []
            self.add_score_to_account(win_loss)

    def add_score_to_account(self, win_loss):
        self.account_scores[self.account_in_action].append(int(self.score))
        self.account_scores[self.account_in_action].append(str(win_loss))

    def get_num_guesses(self):
        while True:
            try:
                self.guesses = int(input(Hangman.point_system))
            except ValueError:
                print(Hangman.jetwash)
                continue
            if self.guesses < 1:
                print(Hangman.jetwash)
                continue
            return

    def guess_game(self):
        '''first the rules are explained, user is prompted for number of guesses, score is set and then the game loop starts'''
        self.get_num_guesses()
        self.score = 50
        while True:                   #loops through until the game is finished
            if self.check_win():      #checks if the user has won
                print(Hangman.game_won)
                print("\nThe word was: {}".format(self.word))
                return
            if self.guesses <= 0:    #checks if the user has lost
                print("\nThe word was {}".format(self.word))
                print(Hangman.jetwash)
                return
            self.print_word()        #prints out the word with letters that have been guessed as correct
            self.guessed_letters()   #tells the user what letters he has guessed
            print("\nYou have ", self.guesses, " guesses left.")
            print("\nYour score is ", self.score)
            self.input_guess()       #prompts the user for a guess

    def check_win(self):
        '''checks if the user has won'''
        for idx in range(len(self.revealed_word)):
            if self.revealed_word[idx] == "-":
                return False
        return True

    def get_guess(self):
        while True:
            new_guess = input("\nTalk to me, Goose.\n\nYour guess: ").lower()
            length = len(new_guess)
            if new_guess in self.false_guesses:
                print(Hangman.already_guessed)
                continue
            if new_guess in self.revealed_word:
                print(Hangman.already_guessed)
                continue
            if not new_guess.isalpha():
                print("\nInvalid guess.")
                continue
            for word in self.false_guesses:
                if word in new_guess:
                    print("\nA previous guess is a substring in this guess.")
                    break
            else:
                return new_guess
                

    def input_guess(self):
        '''prompts the user for a guess, one letter or multiple, and checks if the letters are in the word, changes the score and guessing appropietly'''
        new_guess = self.get_guess()
        length = len(new_guess)
        if length == 1:
            if new_guess not in self.word:
                self.guesses -= 1
                self.score -= 15
                self.false_guesses.append(new_guess)
                print(Hangman.wrong_guess)
                return
            for idx in range(len(self.word)):
                if self.word[idx] == new_guess:
                    self.revealed_word[idx] = new_guess
            print(Hangman.correct_guess)
            self.score += 15
        else:
            counter = 0
            for idx in range(len(self.word)-length):
                string = ""
                string = string.join(self.word[idx:idx+length])
                if string == new_guess:
                    counter += 1
                    self.revealed_word[idx:idx+length] = new_guess
                    print(Hangman.correct_guess)
            if counter == 0:
                self.guesses -= 1
                self.score -= 10*length
                self.false_guesses.append(new_guess)
                print(Hangman.wrong_guess)
                return
            self.score += 10*length

    def guessed_letters(self):
        '''displayed what letters the user has guessed that are not in the word'''
        string = ""
        for letter in self.false_guesses:
            string += str(letter) + " "
        if string != "":
            print("\nYou have already guessed: {}".format(string))

    def print_word(self):
        '''displayes the word with unguessed letters as - and guessed letters displayed'''
        string = ""
        print("\n\n\n\n\n\n\nYour word is: ", string.join(self.revealed_word))

    def words_to_list(self):
        '''function that runs at the beginning of the program and puts the word database into a list so that the list can be checked instead of iterating through the database everytime that a new word is needed, also keeps track of the amount of words in the database'''
        with open("words.txt", "r") as file:
            for line in file:
                self.total_word_list.append(line.strip())
                self.total_word_counter += 1

    def select_word(self):
        '''randomly selects a word from the database, nota bene the database has been imported into a list'''
        rand_number = random.randint(0, self.total_word_counter-1)
        self.word = self.total_word_list[rand_number].lower()
        self.revealed_word = []
        self.false_guesses = []
        for letter in self.word:
            if letter == " ":
                self.revealed_word.append(" ")
            else:
                self.revealed_word.append("-")

    def new_word(self):
        '''prompts the user if he wants to add a word the database'''
        word = str(input(Hangman.add_to_wordbank))
        if word == "y":
            self.input_word()
            return
        if word != "n" and word != "y":
            print(Hangman.jetwash)
            return self.new_word()

    def input_word(self):
        '''asks the user what word he wants to add, adds the word the database file and to the word list'''
        input_word = str(input("\nWhat Top Gun word do you want to input? : ")).lower()
        if not isinstance(input_word, str):
            print(Hangman.jetwash)
            return self.input_word()
        if not input_word.isalpha():
            print(Hangman.jetwash)
            return self.input_word()
        if input_word:
            file = open("words.txt", "a")
            file.write(input_word)
            file.write('\n')
            self.total_word_list.append(input_word)
            self.total_word_counter += 1

    def accounts_to_list(self):
        '''function that runs at the start of the program and changes the account database into a list so that the database does not need to be traversed again'''
        file = open("account_database.txt", "r")
        for line in file:
            if line:
                self.total_account_list[line.split()[0]] = line.split()[1]

    def account(self):
        '''asks the user what account he wants to use, if the account already exists then input password but if the account does not exist the password is created and inserted into the database, in both cases the current account variable is set'''
        account = str(input(Hangman.greeting))
        account_strip = account.replace(" ", "")
        account_strip = account_strip.replace("\t", "")
        account_strip = account_strip.replace("\n", "")
        if not isinstance(account, str) or len(account_strip) == 0:
            print(Hangman.jetwash)
            return self.account()
        if account in self.total_account_list:
            password = str(input("\nWhat is your password?: "))
            pass_hash = hashlib.sha256(password.encode()).hexdigest()
            if self.total_account_list[account] == pass_hash:
                self.account_in_action = str(account)
                return
            else:
                print("\nWrong password")
                return self.account()
        else:
            password = str(input("\nWhat password do you want for your account?: "))
            password_strip = password.replace(" ", "")
            password_strip = password_strip.replace("\t", "")
            if not isinstance(password, str) or len(password_strip)==0:
                print(Hangman.jetwash)
                return self.account()
            pass_hash = hashlib.sha256(password.encode()).hexdigest()
            self.total_account_list[account] = pass_hash
            file = open("account_database.txt", "a")
            file.write(str(account))
            file.write(" ")
            file.write(pass_hash)
            file.write("\n")
            self.account_in_action = str(account)
            return

    def scores_to_list(self):
        '''converts the history of all accounts into dictionary that can be accessed easily instead of traversing the database constantly'''
        file = open("account_scores.txt", "r")
        for line in file:
            account = line.strip().split()[0]
            score = line.strip().split()[1]
            win_loss = line.strip().split()[2]
            if account in self.account_scores:
                self.account_scores[account].append(int(score))
                self.account_scores[account].append(str(win_loss))
            else:
                self.account_scores[account] = []
                self.account_scores[account].append(int(score))
                self.account_scores[account].append(str(win_loss))

h = Hangman()
h.start_game()